/* Code for tables II and III from
"The Effect of SOX Section 404: Costs, Earnings Quality and Stock Prices." Journal of Finance, 2010, 65 (3), 1163-1196.
*/

set more off 
use "D:\1-PROJECTS\Completed\SOX\Data-and-Code\sox-404-dataset.dta", clear

// Check for unique level of observation : firm-treatment year
bysort gvkey year_tr: keep if _n==1

// Prepare sample and controls
*Float and other controls;
local  float=" pfl_5  pfl_5_2 pfl_5_3"
local controls=" l_sales l_assets l_size4 lev invrec big_auditor   busseg geoseg "

// set constant sample for the table
gen avail=(total_audit~=. & l_sales~=. &  l_assets~=. &  l_size4~=. &  lev~=. &  invrec~=. &  ///
big_auditor~=. &  busseg~=. &  geoseg~=. &  pfl_5~=. & pfl_3~=. )

//Assets used to scale MR coefficient;
sum total_audit if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, detail
local mean_audit=r(mean)

// Sample size
count if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1

// Table II

* Short AF OLS;
reg  l_total_audit mr_5 `float' industry1-industry10 if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust

* Long AF OLS;
reg l_total_audit mr_5 `float' `controls' industry1-industry10 if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust

* Short AF IV;
ivreg l_total_audit (mr_5=dt3) industry1-industry10 if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust first

* Long AF IV;
ivreg l_total_audit (mr_5=dt3) `controls' industry1-industry10 if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust first


// Table III
//Float and other controls;
local  float=" pfl_5  pfl_5_2 pfl_5_3";
local controls=" cfo chnetinc negcf  be_me big_auditor size4 ";

// set constant sample for the table
drop avail
gen avail=0
replace avail = (dta_mod~=. & ta_assets1~=. & pfl_5~=. & cfo~=. & chnetinc~=.  &  ///
 negcf~=. &  be_me~=. & big_auditor~=.  & size4~=. & pfl_3~=.)

sort gvkey year_tr
tsset gvkey year_tr

//Assets used to scale MR coefficient;
sum L.assets if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, detail
local L_assets=r(mean)

count if   pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1

* Short TA OLS;
reg  ta_assets1  mr_5 `float' industry1-industry10 if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust

* Long TA OLS;
reg ta_assets1 mr_5 `float' `controls' industry1-industry10 if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust

* Short TA IV;
ivreg ta_assets1 (mr_5=dt3) industry1-industry10 if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1,   robust first

* Long TA IV;
ivreg ta_assets1 (mr_5=dt3) `controls' industry1-industry10 if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1,  robust first

* Short DTA OLS;
reg dta_mod mr_5 `float' if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust

* Long DTA OLS;
reg dta_mod mr_5 `float' `controls' if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust


* Short DTA IV;
ivreg dta_mod (mr_5=dt3)  if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust first

* Long DTA OLS;
ivreg dta_mod (mr_5=dt3) `controls' if  pfl_ok==1 &  pfl_5>50 & pfl_5<100 & year_tr==5 & avail==1, robust first



